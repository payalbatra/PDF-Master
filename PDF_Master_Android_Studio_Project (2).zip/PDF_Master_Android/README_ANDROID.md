# PDF Master — Android Studio project

This is an Android wrapper project around the PDF Master web app. It is **not a compiled APK yet**. Build it on Windows using Android Studio.

## Build the APK on Windows
1. Install **Android Studio** from https://developer.android.com/studio.
2. Extract this ZIP to a normal folder, for example `C:\PDF_Master_Android`.
3. Open Android Studio → **Open** → select the extracted `PDF_Master_Android` folder (the folder containing `settings.gradle`).
4. Allow Gradle sync and install the Android SDK Platform 35 if Android Studio asks.
5. Wait for sync to finish. If prompted, accept the Android Gradle plugin / SDK licenses.
6. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. When the build completes, click **locate**. The APK should be at `app\build\outputs\apk\debug\app-debug.apk`.
8. Copy `app-debug.apk` to your Android phone, open it, and allow installation from that source if Android asks.

## App details
- App name: PDF Master
- Application ID: `com.yestolearning.pdfmaster`
- Minimum Android: Android 6.0 (API 23)
- Camera permission is requested only when the scanner uses the camera.
- Internet permission is used for the conversion/OCR libraries loaded from public CDNs. First launch and some features need internet.
- File picker supports selecting one or more files.

## Important testing notes
This is a first test build project, not a production release. Please test camera access, file selection, and each PDF operation on your phone. The web app still has the feature limitations described in `app/src/main/assets/index.html` / original starter README: office conversions are simplified, compression is lossy rasterization, comparison is text-based, and advanced auto document-edge detection is not implemented. Do not publish this build until it has been thoroughly tested and a privacy policy and store requirements are addressed.
